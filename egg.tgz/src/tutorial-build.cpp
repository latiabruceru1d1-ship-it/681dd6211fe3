// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("tutorial build\n", stdout);
  return lionss_run_workload("tutorial-build");
}
