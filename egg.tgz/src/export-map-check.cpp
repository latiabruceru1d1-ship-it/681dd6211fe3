// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("export map check\n", stdout);
  return lionss_run_workload("export-map-check");
}
