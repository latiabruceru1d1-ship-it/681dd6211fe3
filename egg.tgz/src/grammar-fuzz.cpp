// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("grammar fuzz\n", stdout);
  return lionss_run_workload("grammar-fuzz");
}
