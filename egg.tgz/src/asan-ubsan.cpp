// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("asan ubsan\n", stdout);
  return lionss_run_workload("asan-ubsan");
}
