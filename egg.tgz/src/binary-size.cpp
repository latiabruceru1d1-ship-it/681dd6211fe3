// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("binary size\n", stdout);
  return lionss_run_workload("binary-size");
}
