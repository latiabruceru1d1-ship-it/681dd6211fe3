// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("strip check"); }
int main(){
  announce();
  return lionss_run_workload("strip-check");
}
